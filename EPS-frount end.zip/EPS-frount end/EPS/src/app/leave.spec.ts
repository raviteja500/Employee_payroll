import { Leave } from './leave';

describe('Leave', () => {
  it('should create an instance', () => {
    expect(new Leave()).toBeTruthy();
  });
});
