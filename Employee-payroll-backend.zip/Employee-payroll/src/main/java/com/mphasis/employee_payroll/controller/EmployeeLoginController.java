package com.mphasis.employee_payroll.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mphasis.employee_payroll.model.EmployeeLogin;
import com.mphasis.employee_payroll.service.EmployeeLoginService;

@RestController
@RequestMapping("/api/v1")
public class EmployeeLoginController {

	private EmployeeLoginService employeeLoginService;

	public EmployeeLoginController(EmployeeLoginService employeeLoginService) {
		super();
		this.employeeLoginService = employeeLoginService;
	}

	@PostMapping("/employee_login")
	public ResponseEntity<EmployeeLogin> saveEmployee(@RequestBody EmployeeLogin employeeLogin) {
		return new ResponseEntity<EmployeeLogin>(employeeLoginService.saveEmployee(employeeLogin), HttpStatus.CREATED);
	}
}