package com.mphasis.employee_payroll.controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mphasis.employee_payroll.model.EmployeeRegistration;
import com.mphasis.employee_payroll.service.EmployeeRegistrationService;

@RestController
@RequestMapping("/api/v1")
public class EmployeeRegistrationController {

	private EmployeeRegistrationService employeeRegistrationService;

	public EmployeeRegistrationController(EmployeeRegistrationService employeeRegistrationService) {
		super();
		this.employeeRegistrationService = employeeRegistrationService;
	}

	@PostMapping("/addEmployee_registration")
	public ResponseEntity<EmployeeRegistration> saveEmployeeRegistration(@RequestBody EmployeeRegistration employeeRegistration) {
		return new ResponseEntity<EmployeeRegistration>(
				employeeRegistrationService.saveEmployeeRegistration(employeeRegistration), HttpStatus.CREATED);
	}

	@GetMapping("/viewEmployee")
	public List<EmployeeRegistration> getAllEmployee() {
		return employeeRegistrationService.getAllEmployee();
	}

	@GetMapping("/getEmployee/{id}")
	public ResponseEntity<EmployeeRegistration> getEmployeeById(@PathVariable("id") long employeeId) {
		return new ResponseEntity<EmployeeRegistration>(
				employeeRegistrationService.getEmployeeRegistrationById(employeeId), HttpStatus.OK);
	}

}