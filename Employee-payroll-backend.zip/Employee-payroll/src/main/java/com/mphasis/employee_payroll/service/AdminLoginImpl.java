package com.mphasis.employee_payroll.service;

import org.springframework.stereotype.Service;

import com.mphasis.employee_payroll.model.AdminLogin;
import com.mphasis.employee_payroll.repository.AdminLoginRepository;

@Service
public class AdminLoginImpl implements AdminLoginService {

	private AdminLoginRepository adminLoginRepository;

	public AdminLoginImpl(AdminLoginRepository adminLoginRepository) {
		super();
		this.adminLoginRepository = adminLoginRepository;
	}

	@Override
	public AdminLogin saveAdmin(AdminLogin adminLogin) {
		return adminLoginRepository.save(adminLogin);
	}
}
