package com.mphasis.employee_payroll.service;

import com.mphasis.employee_payroll.model.AdminLogin;

public interface AdminLoginService {
	AdminLogin saveAdmin(AdminLogin adminLogin);

}