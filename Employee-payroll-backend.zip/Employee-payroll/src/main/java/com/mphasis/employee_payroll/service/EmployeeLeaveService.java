package com.mphasis.employee_payroll.service;

import java.util.List;

import com.mphasis.employee_payroll.model.EmployeeLeave;

public interface EmployeeLeaveService {
	EmployeeLeave saveEmployeeLeave(EmployeeLeave employeeLeave);

	List<EmployeeLeave> getAllLeave();

}