package com.mphasis.employee_payroll.service;

import org.springframework.stereotype.Service;

import com.mphasis.employee_payroll.model.EmployeeLogin;
import com.mphasis.employee_payroll.repository.EmployeeLoginRepository;

@Service
public class EmployeeLoginImpl implements EmployeeLoginService {

	private EmployeeLoginRepository employeeLoginRepository;

	public EmployeeLoginImpl(EmployeeLoginRepository employeeLoginRepository) {
		super();
		this.employeeLoginRepository = employeeLoginRepository;
	}

	@Override
	public EmployeeLogin saveEmployee(EmployeeLogin employeeLogin) {
		return employeeLoginRepository.save(employeeLogin);
	}
}
