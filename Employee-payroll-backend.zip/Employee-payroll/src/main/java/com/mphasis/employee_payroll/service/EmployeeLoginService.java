package com.mphasis.employee_payroll.service;

import com.mphasis.employee_payroll.model.EmployeeLogin;

public interface EmployeeLoginService {
	EmployeeLogin saveEmployee(EmployeeLogin employeeLogin);

}